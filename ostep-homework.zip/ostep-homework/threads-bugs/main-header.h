#ifndef __main_header_h__
#define __main_header_h__

#define MAX_THREADS (100)

int loops = 1;
int verbose = 0;
int num_threads = 2;
int do_timing = 0;
int cause_deadlock = 0;
int enable_parallelism = 0;

#endif // __main_header_h__
